#include <stdio.h>
int main(void){
	int x, y;
	int razn;
	scanf("%d%d", &x, &y);
	razn = (x-y);
	printf("%d\n", razn);
	return 0;
}
