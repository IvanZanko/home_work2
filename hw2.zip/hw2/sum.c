#include <stdio.h>
int main(void){
	int x, y, z;
	int sum;
	int umn;
	scanf("%d%d%d", &x, &y, &z);
	sum = (x+y+z);
	printf("%d\n", sum);
	umn = (x*y*z);
	printf("%d\n", umn);
	return 0;
}
