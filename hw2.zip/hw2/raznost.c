#include <stdio.h>
int main(void)
{
int x;
float average;
 scanf("%d", &x);
 average = (x / 1000) + ((x % 1000) / 100) + ((x % 100) / 10) + (x % 10);
 average /= 4.;
 printf("%.2f\n", average);
 return 0;
}
